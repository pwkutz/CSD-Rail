Execute the following command from this directory to generate the antlr4 parser.

`antlr4 -Dlanguage=Python3 -o ./../crmapver/verification/hol/parser/gen -visitor -no-listener Formula.g4`