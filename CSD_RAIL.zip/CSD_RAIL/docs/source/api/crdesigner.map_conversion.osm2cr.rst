crdesigner.map\_conversion.osm2cr package
=========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.osm2cr.converter_modules

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.osm2cr.config
   crdesigner.map_conversion.osm2cr.main

Module contents
---------------

.. automodule:: crdesigner.map_conversion.osm2cr
   :members:
   :undoc-members:
   :show-inheritance:
