crdesigner.map\_conversion.osm2cr.converter\_modules.cr\_operations.cleanup module
==================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.cr_operations.cleanup
   :members:
   :undoc-members:
   :show-inheritance:
