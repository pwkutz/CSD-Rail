crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.gui\_embedding module
================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.gui_embedding
   :members:
   :undoc-members:
   :show-inheritance:
