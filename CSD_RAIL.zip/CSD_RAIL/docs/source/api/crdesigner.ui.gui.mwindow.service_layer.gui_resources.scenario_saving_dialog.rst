crdesigner.ui.gui.mwindow.service\_layer.gui\_resources.scenario\_saving\_dialog module
=======================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_resources.scenario_saving_dialog
   :members:
   :undoc-members:
   :show-inheritance:
