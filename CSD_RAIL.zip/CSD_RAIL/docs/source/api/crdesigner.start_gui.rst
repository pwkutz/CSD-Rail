crdesigner.start\_gui module
============================

.. automodule:: crdesigner.start_gui
   :members:
   :undoc-members:
   :show-inheritance:
