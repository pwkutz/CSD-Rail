crdesigner.ui.gui.mwindow.toolboxes.obstacle\_toolbox.obstacle\_toolbox module
==============================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.obstacle_toolbox.obstacle_toolbox
   :members:
   :undoc-members:
   :show-inheritance:
