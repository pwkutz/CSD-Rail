crdesigner.map\_conversion.lanelet\_lanelet2.cr2lanelet module
==============================================================

.. automodule:: crdesigner.map_conversion.lanelet2.cr2lanelet
   :members:
   :undoc-members:
   :show-inheritance:
