crdesigner.map\_conversion.osm2cr.converter\_modules.graph\_operations.offsetter module
=======================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.graph_operations.offsetter
   :members:
   :undoc-members:
   :show-inheritance:
