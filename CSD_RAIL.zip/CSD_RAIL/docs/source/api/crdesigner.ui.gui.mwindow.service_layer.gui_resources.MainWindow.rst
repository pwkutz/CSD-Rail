crdesigner.ui.gui.mwindow.service\_layer.gui\_resources.MainWindow module
=========================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_resources.MainWindow
   :members:
   :undoc-members:
   :show-inheritance:
