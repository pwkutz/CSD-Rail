crdesigner.ui.gui.mwindow.toolboxes.converter\_toolbox.map\_converter\_toolbox\_ui module
=========================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.map_converter_toolbox_ui
   :members:
   :undoc-members:
   :show-inheritance:
