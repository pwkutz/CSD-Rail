crdesigner.map\_conversion.osm2cr.converter\_modules.utility.geometry module
============================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.utility.geometry
   :members:
   :undoc-members:
   :show-inheritance:
