crdesigner.ui.gui.mwindow.toolboxes.converter\_toolbox.map\_converter\_toolbox module
=====================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.map_converter_toolbox
   :members:
   :undoc-members:
   :show-inheritance:
