crdesigner.ui.gui.mwindow.top\_bar\_wrapper.menu\_bar\_wrapper.menu\_bar\_wrapper module
========================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.top_bar_wrapper.menu_bar_wrapper.menu_bar_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
