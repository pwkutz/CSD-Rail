crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules package
==================================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.GUI_resources

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.actions
   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.aerial_data
   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.config_default
   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.gui
   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.gui_embedding
   crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.plots_interactive

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules
   :members:
   :undoc-members:
   :show-inheritance:
