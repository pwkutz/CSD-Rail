crdesigner.map\_conversion.opendrive.opendrive\_conversion.plane\_elements.traffic\_signals module
==================================================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.traffic_signals
   :members:
   :undoc-members:
   :show-inheritance:
