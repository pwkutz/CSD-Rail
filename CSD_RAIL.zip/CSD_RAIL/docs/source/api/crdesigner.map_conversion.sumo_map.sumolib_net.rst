crdesigner.map\_conversion.sumo\_map.sumolib\_net module
========================================================

.. automodule:: crdesigner.map_conversion.sumo_map.sumolib_net
   :members:
   :undoc-members:
   :show-inheritance:
