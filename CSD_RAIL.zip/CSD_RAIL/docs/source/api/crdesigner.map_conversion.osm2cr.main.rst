crdesigner.map\_conversion.osm2cr.main module
=============================================

.. automodule:: crdesigner.map_conversion.osm2cr.main
   :members:
   :undoc-members:
   :show-inheritance:
