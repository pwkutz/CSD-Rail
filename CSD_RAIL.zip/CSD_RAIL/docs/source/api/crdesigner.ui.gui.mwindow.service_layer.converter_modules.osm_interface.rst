crdesigner.ui.gui.mwindow.service\_layer.converter\_modules.osm\_interface module
=================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.converter_modules.osm_interface
   :members:
   :undoc-members:
   :show-inheritance:
