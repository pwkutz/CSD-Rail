crdesigner.map\_conversion.sumo\_map.cr2sumo.traffic\_sign module
=================================================================

.. automodule:: crdesigner.map_conversion.sumo_map.cr2sumo.traffic_sign
   :members:
   :undoc-members:
   :show-inheritance:
