crdesigner.map\_conversion.opendrive.opendrive\_conversion.plane\_elements.plane\_group module
==============================================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.plane_group
   :members:
   :undoc-members:
   :show-inheritance:
