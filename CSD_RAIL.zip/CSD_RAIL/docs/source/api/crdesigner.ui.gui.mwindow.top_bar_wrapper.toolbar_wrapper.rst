crdesigner.ui.gui.mwindow.top\_bar\_wrapper.toolbar\_wrapper package
====================================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.top_bar_wrapper.toolbar_wrapper.toolbar_wrapper

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow.top_bar_wrapper.toolbar_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
