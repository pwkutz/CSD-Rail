crdesigner.ui.gui.mwindow.service\_layer.gui\_resources.gui\_settings\_ui module
================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_resources.gui_settings_ui
   :members:
   :undoc-members:
   :show-inheritance:
