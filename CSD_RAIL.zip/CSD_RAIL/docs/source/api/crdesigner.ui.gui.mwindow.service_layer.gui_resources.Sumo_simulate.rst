crdesigner.ui.gui.mwindow.service\_layer.gui\_resources.Sumo\_simulate module
=============================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_resources.Sumo_simulate
   :members:
   :undoc-members:
   :show-inheritance:
