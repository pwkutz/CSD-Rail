crdesigner.ui.gui.mwindow.service\_layer.help\_actions module
=============================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.help_actions
   :members:
   :undoc-members:
   :show-inheritance:
