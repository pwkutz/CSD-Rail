crdesigner.map\_conversion.osm2cr.config module
===============================================

.. automodule:: crdesigner.map_conversion.osm2cr.config
   :members:
   :undoc-members:
   :show-inheritance:
