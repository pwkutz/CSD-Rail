crdesigner.map\_conversion.sumo\_map.config module
==================================================

.. automodule:: crdesigner.map_conversion.sumo_map.config
   :members:
   :undoc-members:
   :show-inheritance:
