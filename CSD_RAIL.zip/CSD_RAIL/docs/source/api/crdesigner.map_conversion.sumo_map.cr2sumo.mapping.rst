crdesigner.map\_conversion.sumo\_map.cr2sumo.mapping module
===========================================================

.. automodule:: crdesigner.map_conversion.sumo_map.cr2sumo.mapping
   :members:
   :undoc-members:
   :show-inheritance:
