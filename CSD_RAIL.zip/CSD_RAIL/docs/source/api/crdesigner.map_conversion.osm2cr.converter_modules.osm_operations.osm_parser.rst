crdesigner.map\_conversion.osm2cr.converter\_modules.osm\_operations.osm\_parser module
=======================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.osm_operations.osm_parser
   :members:
   :undoc-members:
   :show-inheritance:
