crdesigner.ui.gui.mwindow.animated\_viewer\_wrapper.commonroad\_viewer.service\_layer.scenario\_resizer module
==============================================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.animated_viewer_wrapper.commonroad_viewer.service_layer.scenario_resizer
   :members:
   :undoc-members:
   :show-inheritance:
