crdesigner.map\_conversion.opendrive.opendrive\_parser.elements.roadLanes module
================================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser.elements.roadLanes
   :members:
   :undoc-members:
   :show-inheritance:
