crdesigner.map\_conversion.sumo\_map package
============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.sumo_map.cr2sumo

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.sumo_map.config
   crdesigner.map_conversion.sumo_map.errors
   crdesigner.map_conversion.sumo_map.merge
   crdesigner.map_conversion.sumo_map.sumo2cr
   crdesigner.map_conversion.sumo_map.sumolib_net
   crdesigner.map_conversion.sumo_map.util

Module contents
---------------

.. automodule:: crdesigner.map_conversion.sumo_map
   :members:
   :undoc-members:
   :show-inheritance:
