crdesigner.ui.gui.mwindow.mwindow module
========================================

.. automodule:: crdesigner.ui.gui.mwindow.mwindow
   :members:
   :undoc-members:
   :show-inheritance:
