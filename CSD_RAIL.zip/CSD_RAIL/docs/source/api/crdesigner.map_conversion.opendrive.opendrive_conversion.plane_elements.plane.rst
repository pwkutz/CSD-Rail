crdesigner.map\_conversion.opendrive.opendrive\_conversion.plane\_elements.plane module
=======================================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.plane
   :members:
   :undoc-members:
   :show-inheritance:
