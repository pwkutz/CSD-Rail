crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.gui module
=====================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.gui
   :members:
   :undoc-members:
   :show-inheritance:
