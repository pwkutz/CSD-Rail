crdesigner.map\_conversion.osm2cr.converter\_modules.utility.idgenerator module
===============================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.utility.idgenerator
   :members:
   :undoc-members:
   :show-inheritance:
