crdesigner.ui.gui.mwindow.service\_layer.config module
======================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.config
   :members:
   :undoc-members:
   :show-inheritance:
