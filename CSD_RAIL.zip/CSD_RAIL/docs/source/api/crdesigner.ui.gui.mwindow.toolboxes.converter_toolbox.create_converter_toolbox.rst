crdesigner.ui.gui.mwindow.toolboxes.converter\_toolbox.create\_converter\_toolbox module
========================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.create_converter_toolbox
   :members:
   :undoc-members:
   :show-inheritance:
