crdesigner.map\_conversion.common package
=========================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.common.utils

Module contents
---------------

.. automodule:: crdesigner.map_conversion.common
   :members:
   :undoc-members:
   :show-inheritance:
