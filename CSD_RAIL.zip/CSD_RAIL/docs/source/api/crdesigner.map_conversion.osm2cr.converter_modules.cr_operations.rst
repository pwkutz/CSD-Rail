crdesigner.map\_conversion.osm2cr.converter\_modules.cr\_operations package
===========================================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.osm2cr.converter_modules.cr_operations.cleanup
   crdesigner.map_conversion.osm2cr.converter_modules.cr_operations.export

Module contents
---------------

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.cr_operations
   :members:
   :undoc-members:
   :show-inheritance:
