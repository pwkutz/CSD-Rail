crdesigner.map\_conversion.sumo\_map.sumo2cr module
===================================================

.. automodule:: crdesigner.map_conversion.sumo_map.sumo2cr
   :members:
   :undoc-members:
   :show-inheritance:
