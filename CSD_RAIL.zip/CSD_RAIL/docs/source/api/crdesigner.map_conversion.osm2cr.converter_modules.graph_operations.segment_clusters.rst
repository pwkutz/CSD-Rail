crdesigner.map\_conversion.osm2cr.converter\_modules.graph\_operations.segment\_clusters module
===============================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.graph_operations.segment_clusters
   :members:
   :undoc-members:
   :show-inheritance:
