crdesigner.ui.gui.gui module
============================

.. automodule:: crdesigner.ui.gui.gui
   :members:
   :undoc-members:
   :show-inheritance:
