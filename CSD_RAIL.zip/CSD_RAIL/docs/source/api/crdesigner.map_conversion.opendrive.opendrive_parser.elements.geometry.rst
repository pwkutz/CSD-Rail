crdesigner.map\_conversion.opendrive.opendrive\_parser.elements.geometry module
===============================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser.elements.geometry
   :members:
   :undoc-members:
   :show-inheritance:
