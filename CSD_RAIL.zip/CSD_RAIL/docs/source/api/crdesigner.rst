crdesigner package
==================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.configurations
   crdesigner.map_conversion
   crdesigner.ui

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.start_gui

Module contents
---------------

.. automodule:: crdesigner
   :members:
   :undoc-members:
   :show-inheritance:
