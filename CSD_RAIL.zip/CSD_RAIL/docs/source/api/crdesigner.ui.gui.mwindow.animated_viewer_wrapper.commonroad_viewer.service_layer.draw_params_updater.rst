crdesigner.ui.gui.mwindow.animated\_viewer\_wrapper.commonroad\_viewer.service\_layer.draw\_params\_updater module
==================================================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.animated_viewer_wrapper.commonroad_viewer.service_layer.draw_params_updater
   :members:
   :undoc-members:
   :show-inheritance:
