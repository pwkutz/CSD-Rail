crdesigner.ui.cli package
=========================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.cli.command_line

Module contents
---------------

.. automodule:: crdesigner.ui.cli
   :members:
   :undoc-members:
   :show-inheritance:
