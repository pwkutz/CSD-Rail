crdesigner.ui.gui.mwindow.top\_bar\_wrapper.service\_layer.file\_actions module
===============================================================================

.. automodule:: crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer.file_actions
   :members:
   :undoc-members:
   :show-inheritance:
