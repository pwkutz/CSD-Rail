crdesigner.map\_conversion.osm2cr.converter\_modules.graph\_operations.traffic\_sign\_parser module
===================================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.graph_operations.traffic_sign_parser
   :members:
   :undoc-members:
   :show-inheritance:
