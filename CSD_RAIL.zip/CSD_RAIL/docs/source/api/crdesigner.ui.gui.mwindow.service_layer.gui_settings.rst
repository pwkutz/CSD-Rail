crdesigner.ui.gui.mwindow.service\_layer.gui\_settings module
=============================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_settings
   :members:
   :undoc-members:
   :show-inheritance:
