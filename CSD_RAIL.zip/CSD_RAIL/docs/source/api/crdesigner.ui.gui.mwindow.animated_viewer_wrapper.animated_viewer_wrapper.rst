crdesigner.ui.gui.mwindow.animated\_viewer\_wrapper.animated\_viewer\_wrapper module
====================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.animated_viewer_wrapper.animated_viewer_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
