osm2cr.converter\_modules.utility package
=========================================

Submodules
----------

osm2cr.converter\_modules.utility.custom\_types module
------------------------------------------------------

.. automodule:: osm2cr.converter_modules.utility.custom_types
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.utility.geometry module
-------------------------------------------------

.. automodule:: osm2cr.converter_modules.utility.geometry
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.utility.geonamesID module
---------------------------------------------------

.. automodule:: osm2cr.converter_modules.utility.geonamesID
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.utility.graph\_analysis module
--------------------------------------------------------

.. automodule:: osm2cr.converter_modules.utility.graph_analysis
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.utility.idgenerator module
----------------------------------------------------

.. automodule:: osm2cr.converter_modules.utility.idgenerator
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.utility.plots module
----------------------------------------------

.. automodule:: osm2cr.converter_modules.utility.plots
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: osm2cr.converter_modules.utility
   :members:
   :undoc-members:
   :show-inheritance:
