osm2cr.converter\_modules package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   osm2cr.converter_modules.cr_operations
   osm2cr.converter_modules.graph_operations
   osm2cr.converter_modules.intermediate_operations
   osm2cr.converter_modules.osm_operations
   osm2cr.converter_modules.utility

Submodules
----------

osm2cr.converter\_modules.converter module
------------------------------------------

.. automodule:: osm2cr.converter_modules.converter
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: osm2cr.converter_modules
   :members:
   :undoc-members:
   :show-inheritance:
