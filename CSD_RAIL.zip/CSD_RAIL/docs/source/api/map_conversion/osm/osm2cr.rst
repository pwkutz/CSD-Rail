osm2cr package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   osm2cr.converter_modules

Submodules
----------

osm2cr.config module
--------------------

.. automodule:: osm2cr.config
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.main module
------------------

.. automodule:: osm2cr.main
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: osm2cr
   :members:
   :undoc-members:
   :show-inheritance:
