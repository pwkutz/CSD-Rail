osm2cr.converter\_modules.cr\_operations package
================================================

Submodules
----------

osm2cr.converter\_modules.cr\_operations.cleanup module
-------------------------------------------------------

.. automodule:: osm2cr.converter_modules.cr_operations.cleanup
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.cr\_operations.export module
------------------------------------------------------

.. automodule:: osm2cr.converter_modules.cr_operations.export
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: osm2cr.converter_modules.cr_operations
   :members:
   :undoc-members:
   :show-inheritance:
