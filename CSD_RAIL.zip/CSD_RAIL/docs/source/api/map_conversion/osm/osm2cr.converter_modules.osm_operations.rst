osm2cr.converter\_modules.osm\_operations package
=================================================

Submodules
----------

osm2cr.converter\_modules.osm\_operations.downloader module
-----------------------------------------------------------

.. automodule:: osm2cr.converter_modules.osm_operations.downloader
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.osm\_operations.info\_deduction module
----------------------------------------------------------------

.. automodule:: osm2cr.converter_modules.osm_operations.info_deduction
   :members:
   :undoc-members:
   :show-inheritance:

osm2cr.converter\_modules.osm\_operations.osm\_parser module
------------------------------------------------------------

.. automodule:: osm2cr.converter_modules.osm_operations.osm_parser
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: osm2cr.converter_modules.osm_operations
   :members:
   :undoc-members:
   :show-inheritance:
