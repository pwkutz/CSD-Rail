opendrive.opendrive\_conversion.plane\_elements package
=======================================================

Submodules
----------

opendrive.opendrive\_conversion.plane\_elements.border module
-------------------------------------------------------------

.. automodule:: opendrive.opendrive_conversion.plane_elements.border
   :members:
   :undoc-members:
   :show-inheritance:

opendrive.opendrive\_conversion.plane\_elements.crosswalks module
-----------------------------------------------------------------

.. automodule:: opendrive.opendrive_conversion.plane_elements.crosswalks
   :members:
   :undoc-members:
   :show-inheritance:

opendrive.opendrive\_conversion.plane\_elements.geo\_reference module
---------------------------------------------------------------------

.. automodule:: opendrive.opendrive_conversion.plane_elements.geo_reference
   :members:
   :undoc-members:
   :show-inheritance:

opendrive.opendrive\_conversion.plane\_elements.plane module
------------------------------------------------------------

.. automodule:: opendrive.opendrive_conversion.plane_elements.plane
   :members:
   :undoc-members:
   :show-inheritance:

opendrive.opendrive\_conversion.plane\_elements.plane\_group module
-------------------------------------------------------------------

.. automodule:: opendrive.opendrive_conversion.plane_elements.plane_group
   :members:
   :undoc-members:
   :show-inheritance:

opendrive.opendrive\_conversion.plane\_elements.traffic\_signals module
-----------------------------------------------------------------------

.. automodule:: opendrive.opendrive_conversion.plane_elements.traffic_signals
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: opendrive.opendrive_conversion.plane_elements
   :members:
   :undoc-members:
   :show-inheritance:
