crdesigner.map\_conversion.opendrive.opendrive\_conversion.plane\_elements package
==================================================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.border
   crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.crosswalks
   crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.geo_reference
   crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.plane
   crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.plane_group
   crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.traffic_signals

Module contents
---------------

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements
   :members:
   :undoc-members:
   :show-inheritance:
