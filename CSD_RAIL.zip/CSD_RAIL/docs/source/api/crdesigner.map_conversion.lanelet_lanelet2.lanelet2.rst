crdesigner.map\_conversion.lanelet\_lanelet2.lanelet2 module
============================================================

.. automodule:: crdesigner.map_conversion.lanelet2.lanelet2
   :members:
   :undoc-members:
   :show-inheritance:
