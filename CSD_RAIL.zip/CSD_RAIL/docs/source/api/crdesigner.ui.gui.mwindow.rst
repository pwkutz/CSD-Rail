crdesigner.ui.gui.mwindow package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.animated_viewer_wrapper
   crdesigner.ui.gui.mwindow.crdesigner_console_wrapper
   crdesigner.ui.gui.mwindow.service_layer
   crdesigner.ui.gui.mwindow.toolboxes
   crdesigner.ui.gui.mwindow.top_bar_wrapper

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.mwindow

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow
   :members:
   :undoc-members:
   :show-inheritance:
