crdesigner.ui.gui.mwindow.toolboxes.service\_layer.sumo\_settings module
========================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.service_layer.sumo_settings
   :members:
   :undoc-members:
   :show-inheritance:
