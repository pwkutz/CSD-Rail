crdesigner.map\_conversion.map\_conversion\_interface module
============================================================

.. automodule:: crdesigner.map_conversion.map_conversion_interface
   :members:
   :undoc-members:
   :show-inheritance:
