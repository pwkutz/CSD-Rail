crdesigner.map\_conversion.osm2cr.converter\_modules.graph\_operations.restrictions module
==========================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.graph_operations.restrictions
   :members:
   :undoc-members:
   :show-inheritance:
