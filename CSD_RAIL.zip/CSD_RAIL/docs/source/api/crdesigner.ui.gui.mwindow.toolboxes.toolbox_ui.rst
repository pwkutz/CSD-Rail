crdesigner.ui.gui.mwindow.toolboxes.toolbox\_ui module
======================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.toolbox_ui
   :members:
   :undoc-members:
   :show-inheritance:
