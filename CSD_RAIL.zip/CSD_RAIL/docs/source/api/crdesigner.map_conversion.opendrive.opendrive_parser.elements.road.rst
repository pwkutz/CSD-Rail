crdesigner.map\_conversion.opendrive.opendrive\_parser.elements.road module
===========================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser.elements.road
   :members:
   :undoc-members:
   :show-inheritance:
