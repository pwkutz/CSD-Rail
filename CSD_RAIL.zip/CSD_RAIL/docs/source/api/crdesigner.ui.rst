crdesigner.ui package
=====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.cli
   crdesigner.ui.gui

Module contents
---------------

.. automodule:: crdesigner.ui
   :members:
   :undoc-members:
   :show-inheritance:
