crdesigner.map\_conversion.opendrive.opendrive\_parser.parser module
====================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser.parser
   :members:
   :undoc-members:
   :show-inheritance:
