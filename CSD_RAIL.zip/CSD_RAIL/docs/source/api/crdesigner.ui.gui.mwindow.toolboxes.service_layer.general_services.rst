crdesigner.ui.gui.mwindow.toolboxes.service\_layer.general\_services module
===========================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.service_layer.general_services
   :members:
   :undoc-members:
   :show-inheritance:
