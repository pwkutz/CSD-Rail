crdesigner.map\_conversion.opendrive.opendrive\_parser.elements.roadtype module
===============================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser.elements.roadtype
   :members:
   :undoc-members:
   :show-inheritance:
