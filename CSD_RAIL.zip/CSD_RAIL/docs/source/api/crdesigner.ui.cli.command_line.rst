crdesigner.ui.cli.command\_line module
======================================

.. automodule:: crdesigner.ui.cli.command_line
   :members:
   :undoc-members:
   :show-inheritance:
