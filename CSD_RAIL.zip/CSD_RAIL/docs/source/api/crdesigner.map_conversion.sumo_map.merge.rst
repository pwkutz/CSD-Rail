crdesigner.map\_conversion.sumo\_map.merge module
=================================================

.. automodule:: crdesigner.map_conversion.sumo_map.merge
   :members:
   :undoc-members:
   :show-inheritance:
