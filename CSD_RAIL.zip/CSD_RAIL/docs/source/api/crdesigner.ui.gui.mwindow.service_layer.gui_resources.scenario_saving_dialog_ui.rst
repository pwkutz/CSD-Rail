crdesigner.ui.gui.mwindow.service\_layer.gui\_resources.scenario\_saving\_dialog\_ui module
===========================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_resources.scenario_saving_dialog_ui
   :members:
   :undoc-members:
   :show-inheritance:
