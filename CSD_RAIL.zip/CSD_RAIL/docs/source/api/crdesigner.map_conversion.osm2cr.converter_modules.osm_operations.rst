crdesigner.map\_conversion.osm2cr.converter\_modules.osm\_operations package
============================================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.osm2cr.converter_modules.osm_operations.downloader
   crdesigner.map_conversion.osm2cr.converter_modules.osm_operations.info_deduction
   crdesigner.map_conversion.osm2cr.converter_modules.osm_operations.osm_parser

Module contents
---------------

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.osm_operations
   :members:
   :undoc-members:
   :show-inheritance:
