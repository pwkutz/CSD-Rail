crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.GUI\_resources.lane\_counts module
=============================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.GUI_resources.lane_counts
   :members:
   :undoc-members:
   :show-inheritance:
