crdesigner.map\_conversion.opendrive.opendrive\_conversion.plane\_elements.geo\_reference module
================================================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.geo_reference
   :members:
   :undoc-members:
   :show-inheritance:
