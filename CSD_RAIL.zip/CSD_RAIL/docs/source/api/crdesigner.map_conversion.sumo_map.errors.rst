crdesigner.map\_conversion.sumo\_map.errors module
==================================================

.. automodule:: crdesigner.map_conversion.sumo_map.errors
   :members:
   :undoc-members:
   :show-inheritance:
