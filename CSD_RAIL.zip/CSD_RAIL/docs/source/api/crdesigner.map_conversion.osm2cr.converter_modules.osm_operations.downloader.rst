crdesigner.map\_conversion.osm2cr.converter\_modules.osm\_operations.downloader module
======================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.osm_operations.downloader
   :members:
   :undoc-members:
   :show-inheritance:
