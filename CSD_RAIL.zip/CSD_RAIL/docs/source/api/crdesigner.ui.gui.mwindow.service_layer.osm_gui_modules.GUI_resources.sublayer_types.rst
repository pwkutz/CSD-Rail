crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.GUI\_resources.sublayer\_types module
================================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.GUI_resources.sublayer_types
   :members:
   :undoc-members:
   :show-inheritance:
