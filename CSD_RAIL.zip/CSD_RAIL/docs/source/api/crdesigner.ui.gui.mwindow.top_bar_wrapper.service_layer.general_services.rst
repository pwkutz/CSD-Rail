crdesigner.ui.gui.mwindow.top\_bar\_wrapper.service\_layer.general\_services module
===================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer.general_services
   :members:
   :undoc-members:
   :show-inheritance:
