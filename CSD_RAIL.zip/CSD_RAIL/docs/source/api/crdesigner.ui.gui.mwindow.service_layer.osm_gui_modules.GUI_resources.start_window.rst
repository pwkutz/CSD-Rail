crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.GUI\_resources.start\_window module
==============================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.GUI_resources.start_window
   :members:
   :undoc-members:
   :show-inheritance:
