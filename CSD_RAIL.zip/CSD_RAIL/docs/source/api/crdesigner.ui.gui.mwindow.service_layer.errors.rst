crdesigner.ui.gui.mwindow.service\_layer.errors module
======================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.errors
   :members:
   :undoc-members:
   :show-inheritance:
