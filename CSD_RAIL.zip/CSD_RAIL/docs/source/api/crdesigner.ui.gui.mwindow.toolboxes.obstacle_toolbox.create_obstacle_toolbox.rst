crdesigner.ui.gui.mwindow.toolboxes.obstacle\_toolbox.create\_obstacle\_toolbox module
======================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.obstacle_toolbox.create_obstacle_toolbox
   :members:
   :undoc-members:
   :show-inheritance:
