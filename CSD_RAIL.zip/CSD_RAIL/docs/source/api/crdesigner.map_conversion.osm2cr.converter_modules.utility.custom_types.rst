crdesigner.map\_conversion.osm2cr.converter\_modules.utility.custom\_types module
=================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.utility.custom_types
   :members:
   :undoc-members:
   :show-inheritance:
