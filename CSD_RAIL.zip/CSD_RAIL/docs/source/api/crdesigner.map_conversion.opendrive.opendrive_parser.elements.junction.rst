crdesigner.map\_conversion.opendrive.opendrive\_parser.elements.junction module
===============================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser.elements.junction
   :members:
   :undoc-members:
   :show-inheritance:
