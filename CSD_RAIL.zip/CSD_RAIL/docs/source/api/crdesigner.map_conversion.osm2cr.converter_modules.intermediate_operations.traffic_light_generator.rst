crdesigner.map\_conversion.osm2cr.converter\_modules.intermediate\_operations.traffic\_light\_generator module
==============================================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.intermediate_operations.traffic_light_generator
   :members:
   :undoc-members:
   :show-inheritance:
