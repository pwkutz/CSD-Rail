crdesigner.ui.gui.mwindow.top\_bar\_wrapper.service\_layer package
==================================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer.file_actions
   crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer.general_services
   crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer.help_actions
   crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer.setting_actions

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow.top_bar_wrapper.service_layer
   :members:
   :undoc-members:
   :show-inheritance:
