crdesigner.map\_conversion.osm2cr.converter\_modules.osm\_operations.info\_deduction module
===========================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.osm_operations.info_deduction
   :members:
   :undoc-members:
   :show-inheritance:
