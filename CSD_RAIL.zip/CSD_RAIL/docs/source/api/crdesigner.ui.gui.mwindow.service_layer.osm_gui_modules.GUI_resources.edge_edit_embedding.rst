crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.GUI\_resources.edge\_edit\_embedding module
======================================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.GUI_resources.edge_edit_embedding
   :members:
   :undoc-members:
   :show-inheritance:
