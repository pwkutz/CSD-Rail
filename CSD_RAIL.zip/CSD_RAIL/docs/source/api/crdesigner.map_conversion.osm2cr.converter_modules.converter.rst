crdesigner.map\_conversion.osm2cr.converter\_modules.converter module
=====================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.converter
   :members:
   :undoc-members:
   :show-inheritance:
