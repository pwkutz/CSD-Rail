crdesigner.map\_conversion.osm2cr.converter\_modules.graph\_operations.intersection\_merger module
==================================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.graph_operations.intersection_merger
   :members:
   :undoc-members:
   :show-inheritance:
