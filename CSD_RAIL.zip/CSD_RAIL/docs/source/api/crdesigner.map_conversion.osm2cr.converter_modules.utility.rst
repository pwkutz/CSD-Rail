crdesigner.map\_conversion.osm2cr.converter\_modules.utility package
====================================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.osm2cr.converter_modules.utility.custom_types
   crdesigner.map_conversion.osm2cr.converter_modules.utility.geometry
   crdesigner.map_conversion.osm2cr.converter_modules.utility.geonamesID
   crdesigner.map_conversion.osm2cr.converter_modules.utility.graph_analysis
   crdesigner.map_conversion.osm2cr.converter_modules.utility.idgenerator
   crdesigner.map_conversion.osm2cr.converter_modules.utility.plots

Module contents
---------------

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.utility
   :members:
   :undoc-members:
   :show-inheritance:
