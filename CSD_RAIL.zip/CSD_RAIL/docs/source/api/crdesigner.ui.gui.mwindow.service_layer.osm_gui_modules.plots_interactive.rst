crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.plots\_interactive module
====================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.plots_interactive
   :members:
   :undoc-members:
   :show-inheritance:
