crdesigner.ui.gui.mwindow.crdesigner\_console\_wrapper package
==============================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.crdesigner_console_wrapper.crdesigner_console_wrapper

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow.crdesigner_console_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
