crdesigner.ui.gui.mwindow.service\_layer.util module
====================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.util
   :members:
   :undoc-members:
   :show-inheritance:
