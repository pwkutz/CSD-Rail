crdesigner.map\_conversion.lanelet\_lanelet2.lanelet2\_parser module
====================================================================

.. automodule:: crdesigner.map_conversion.lanelet2.lanelet2_parser
   :members:
   :undoc-members:
   :show-inheritance:
