crdesigner.map\_conversion.opendrive.opendrive\_conversion.plane\_elements.border module
========================================================================================

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_conversion.plane_elements.border
   :members:
   :undoc-members:
   :show-inheritance:
