crdesigner.ui.gui.mwindow.toolboxes.service\_layer package
==========================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.toolboxes.service_layer.general_services

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.service_layer
   :members:
   :undoc-members:
   :show-inheritance:
