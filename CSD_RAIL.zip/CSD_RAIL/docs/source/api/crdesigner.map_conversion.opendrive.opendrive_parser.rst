crdesigner.map\_conversion.opendrive.opendrive\_parser package
==============================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.opendrive.opendrive_parser.elements

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.map_conversion.opendrive.opendrive_parser.parser

Module contents
---------------

.. automodule:: crdesigner.map_conversion.opendrive.opendrive_parser
   :members:
   :undoc-members:
   :show-inheritance:
