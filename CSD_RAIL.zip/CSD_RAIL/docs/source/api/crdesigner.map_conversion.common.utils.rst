crdesigner.map\_conversion.common.utils module
==============================================

.. automodule:: crdesigner.map_conversion.common.utils
   :members:
   :undoc-members:
   :show-inheritance:
