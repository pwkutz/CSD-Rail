crdesigner.ui.gui package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.gui

Module contents
---------------

.. automodule:: crdesigner.ui.gui
   :members:
   :undoc-members:
   :show-inheritance:
