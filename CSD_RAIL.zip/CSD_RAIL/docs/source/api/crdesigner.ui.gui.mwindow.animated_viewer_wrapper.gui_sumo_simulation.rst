crdesigner.ui.gui.mwindow.animated\_viewer\_wrapper.gui\_sumo\_simulation module
================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.animated_viewer_wrapper.gui_sumo_simulation
   :members:
   :undoc-members:
   :show-inheritance:
