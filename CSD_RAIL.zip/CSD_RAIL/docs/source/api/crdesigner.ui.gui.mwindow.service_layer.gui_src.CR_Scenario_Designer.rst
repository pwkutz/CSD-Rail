crdesigner.ui.gui.mwindow.service\_layer.gui\_src.CR\_Scenario\_Designer module
===============================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.gui_src.CR_Scenario_Designer
   :members:
   :undoc-members:
   :show-inheritance:
