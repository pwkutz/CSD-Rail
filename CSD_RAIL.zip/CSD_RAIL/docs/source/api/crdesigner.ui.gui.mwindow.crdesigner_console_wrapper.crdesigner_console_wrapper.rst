crdesigner.ui.gui.mwindow.crdesigner\_console\_wrapper.crdesigner\_console\_wrapper module
==========================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.crdesigner_console_wrapper.crdesigner_console_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
