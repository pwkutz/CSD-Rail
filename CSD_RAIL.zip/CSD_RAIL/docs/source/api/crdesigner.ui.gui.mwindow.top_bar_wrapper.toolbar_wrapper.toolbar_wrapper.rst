crdesigner.ui.gui.mwindow.top\_bar\_wrapper.toolbar\_wrapper.toolbar\_wrapper module
====================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.top_bar_wrapper.toolbar_wrapper.toolbar_wrapper
   :members:
   :undoc-members:
   :show-inheritance:
