crdesigner.ui.gui.mwindow.service\_layer.general\_services module
=================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.general_services
   :members:
   :undoc-members:
   :show-inheritance:
