crdesigner.map\_conversion.osm2cr.converter\_modules.cr\_operations.export module
=================================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.cr_operations.export
   :members:
   :undoc-members:
   :show-inheritance:
