crdesigner.ui.gui.mwindow.toolboxes.converter\_toolbox package
==============================================================

Submodules
----------

.. toctree::
   :maxdepth: 4

   crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.create_converter_toolbox
   crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.map_converter_toolbox
   crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.map_converter_toolbox_ui
   crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox.waitingspinnerwidget

Module contents
---------------

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.converter_toolbox
   :members:
   :undoc-members:
   :show-inheritance:
