crdesigner.ui.gui.mwindow.service\_layer.osm\_gui\_modules.GUI\_resources.settings\_ui module
=============================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.service_layer.osm_gui_modules.GUI_resources.settings_ui
   :members:
   :undoc-members:
   :show-inheritance:
