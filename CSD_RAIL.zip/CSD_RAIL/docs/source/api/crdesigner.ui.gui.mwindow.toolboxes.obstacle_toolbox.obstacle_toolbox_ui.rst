crdesigner.ui.gui.mwindow.toolboxes.obstacle\_toolbox.obstacle\_toolbox\_ui module
==================================================================================

.. automodule:: crdesigner.ui.gui.mwindow.toolboxes.obstacle_toolbox.obstacle_toolbox_ui
   :members:
   :undoc-members:
   :show-inheritance:
