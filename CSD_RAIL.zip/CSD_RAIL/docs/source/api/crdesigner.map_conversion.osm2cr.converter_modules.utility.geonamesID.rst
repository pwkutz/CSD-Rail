crdesigner.map\_conversion.osm2cr.converter\_modules.utility.geonamesID module
==============================================================================

.. automodule:: crdesigner.map_conversion.osm2cr.converter_modules.utility.geonamesID
   :members:
   :undoc-members:
   :show-inheritance:
