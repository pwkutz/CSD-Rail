import os

DIR_AUTOSAVE = os.path.dirname(__file__)