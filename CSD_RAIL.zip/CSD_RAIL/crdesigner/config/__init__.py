import os

CONFIG_DIR = os.path.dirname(__file__)
